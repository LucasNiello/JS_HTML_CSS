# Lista de Tarefas - Melhorias Pizzaria

- [X] **Planejar Alterações:** Detalhar a estratégia para implementar pop-ups estilizados e garantir a editabilidade completa do cardápio.
- [X] **Criar Função Pop-up:** Desenvolver a função JavaScript `showPopup()` reutilizável e o CSS necessário para os pop-ups temporários e estilizados.
- [X] **Implementar Pop-ups (Admin):** Substituir todas as chamadas `alert()` e `confirm()` no `PIZZARIA_admin.js` pela nova função `showPopup()`.
